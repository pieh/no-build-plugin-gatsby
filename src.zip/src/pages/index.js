import * as React from "react";
import { Layout } from "../components/layout";

export default function Home() {
  return <Layout>Hello world!</Layout>;
}
