module.exports = (_req, res) => {
  res.send(`hello`);
};
