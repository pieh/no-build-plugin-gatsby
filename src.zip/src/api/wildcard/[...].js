export default function topLevel(req, res) {
  res.send(`hello`);
}
